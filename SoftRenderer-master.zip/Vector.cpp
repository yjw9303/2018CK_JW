
#include "stdafx.h"
#include "Vector.h"
