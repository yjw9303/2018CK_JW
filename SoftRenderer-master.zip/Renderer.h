#pragma once

void UpdateFrame(void);
