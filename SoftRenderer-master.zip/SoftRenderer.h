#pragma once

#include "resource.h"

extern int g_nClientWidth;
extern int g_nClientHeight;
extern bool g_bIsActive;
